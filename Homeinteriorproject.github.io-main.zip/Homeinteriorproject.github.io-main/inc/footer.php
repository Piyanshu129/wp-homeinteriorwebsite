<footer>
    <p>&copy; 2023 Home Interior Design</p>
</footer>
</body>
</html>